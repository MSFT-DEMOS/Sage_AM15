export interface OrderDetailDelivery {
  deliveryId: number;
  orderId: number;
  orderDetailId: number;
}
