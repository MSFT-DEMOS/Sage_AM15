export interface Delivery {
  deliveryId: number;
  deliveryDate: Date;
  supplierId: number;
}
